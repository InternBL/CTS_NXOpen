﻿using System;
using NXOpen.UF;
namespace SelectionManager
{
	internal class ChangeRefSetSelection : SpecialSelection<NXOpen.Assemblies.Component>
	{

		protected ChangeRefSetSelection(Predicate<NXOpen.Assemblies.Component> selectionPredicate, Scope scope, bool keepHighlighted,string prompt, params UFUi.Mask[] masks)
			: base(selectionPredicate, scope,keepHighlighted,prompt, masks)
		{
		}



		private bool IsSelected = false;

		protected override int SelectionCallback(int numSelected, NXOpen.Tag[] selectedObjects, int numDeselected, NXOpen.Tag[] deselectedObjects, IntPtr userData, IntPtr select)
		{
			return base.SelectionCallback(numSelected, selectedObjects, numDeselected, deselectedObjects, userData, select);
		}
		
	}
}

