﻿using System;
namespace SelectionManager
{
	public static class Masks
	{
		public static NXOpen.UF.UFUi.Mask ComponentMask = new NXOpen.UF.UFUi.Mask();

		public static NXOpen.UF.UFUi.Mask EdgeMask = new NXOpen.UF.UFUi.Mask();

		public static NXOpen.UF.UFUi.Mask BodyMask = new NXOpen.UF.UFUi.Mask();

		public static NXOpen.UF.UFUi.Mask FaceMask = new NXOpen.UF.UFUi.Mask();

		public static NXOpen.UF.UFUi.Mask CurveMask = new NXOpen.UF.UFUi.Mask();
	}
}

