﻿using System;
namespace SelectionManager
{
	public class MyClass
	{
		public MyClass()
		{
		}
	}
}

