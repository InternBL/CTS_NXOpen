﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SelectionManager
{
	public class InnerSelectionException : System.Exception
	{
		public InnerSelectionException(string message) : base(message) { }

		public InnerSelectionException(string message, Exception innerException) : base(message, innerException) { }

	}
}
