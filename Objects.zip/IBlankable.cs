﻿using System;
namespace SelectionManager
{
	public interface IBlankable
	{
		void Blank();
		void Unblank();
		bool IsBlanked { get; }
	}
}

