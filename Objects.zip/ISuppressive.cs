﻿using System;
namespace SelectionManager
{
	public interface ISuppressive
	{
		void Suppress();
		void Unsuppress();
		bool IsSuppressed { get;}
	}
}

