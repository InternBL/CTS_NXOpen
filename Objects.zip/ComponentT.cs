﻿using System;
using NXOpen;
using NXOpen.Assemblies;
using System.Collections.Generic;
using System.Linq;
namespace SelectionManager
{
	public class ComponentT : Snap.NX.NXObject, NXOpen.INXObject
	{
		//Look at Making a displayable object  class
		public NXOpen.Tag Tag { get; protected set; }

		public Snap.NX.Component ComponentSp
		{
			get
			{
				return Snap.NX.Component.Wrap(Tag);
			}
		}

		public Component ComponentNx { get { return ComponentSp.NXOpenComponent; } }

		public ComponentT(NXOpen.Assemblies.Component component) : this(component.Tag) { }

		public ComponentT(Snap.NX.Component component) : this(component.NXOpenComponent) { }

		public ComponentT(NXOpen.Tag tag) : base(tag) { Tag = tag; }

		public NXOpen.Assemblies.ComponentAssembly DirectOwner { get { return ComponentNx.DirectOwner; } }

		public List<ComponentT> Children { get { return ComponentNx.GetChildren().Select(x => new ComponentT(x.Tag)).ToList(); } }

		public string ReferenceSet
		{
			get { return ComponentNx.ReferenceSet; }
			set { ComponentNx.DirectOwner.ReplaceReferenceSet(ComponentSp, value); }
		}

		public string JournalIdentifier { get { return ComponentNx.JournalIdentifier; } }

		Component INXObject.OwningComponent { get { return ComponentNx.OwningComponent; } }

		public BasePart OwningPart { get { return ComponentNx.OwningPart; } }

		INXObject INXObject.Prototype { get { return ComponentNx.Prototype; } }

		public INXObject FindObject(string journalIdentifier) { return ComponentNx.FindObject(journalIdentifier); }

		public void Print() { ComponentNx.Print(); }

		public void SetName(string name) { ComponentNx.SetName(name); }

		public string DisplayName { get { return ComponentNx.DisplayName; } }

		public Snap.Position Origin { get { return ComponentSp.Position; } }

		public Snap.Orientation Orientation { get { return ComponentSp.Orientation; } }

		public static implicit operator TaggedObject(ComponentT component) { return component.ComponentSp.NXOpenTaggedObject; }

		public static implicit operator ComponentT(TaggedObject taggedObject) { return new ComponentT(taggedObject.Tag); }

		public static implicit operator NXOpen.NXObject(ComponentT component) { return (NXOpen.NXObject)component.ComponentNx; }

		public static implicit operator ComponentT(NXOpen.NXObject nxObject) { return new ComponentT(nxObject.Tag); }

		public static implicit operator DisplayableObject(ComponentT component) { return component.NXOpenDisplayableObject; }

		public static implicit operator ComponentT(DisplayableObject displayableObject) { return new ComponentT(displayableObject.Tag); }

		public static implicit operator NXOpen.Assemblies.Component(ComponentT component) { return component.ComponentNx; }

		public static implicit operator ComponentT(NXOpen.Assemblies.Component component) { return new ComponentT(component.Tag); }

		public static implicit operator Snap.NX.Component(ComponentT component) { return Snap.NX.Component.Wrap(component.Tag); }

		public static implicit operator ComponentT(Snap.NX.Component component) { return new ComponentT(component); }






		//SetInstanceAttribute
		//GetInstanceAttribute
		//Suppress()


	}
}