﻿using System;
namespace SelectionManager
{
	public class NXObject : NXOpen.NXObject
	{
		NXObject() : base()
		{
		}

		public NXObject(NXOpen.NXObject nxObject)
		{
			//this.SetUserAttribute(null);
		}

		public new void SetName(string name)
		{
		}
	}
}

